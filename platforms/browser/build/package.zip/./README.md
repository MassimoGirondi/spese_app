#Gestore spese
----
Copyright (C) 2016 Massimo Girondi


Non ti è mai capitato di trovarti a una festa dove ognuno ha portato qualcosa e dover decidere quanto deve pagare ognuno?

Abiti in un appartamento condiviso con altri e dovete decidere quanto paga ognuno per ogni spesa?

Con questa semplice web-app potrai farlo molto semplicemente, dimenticandoti calcolatrice e penna.

Dopo aver inserito i nomi delle persone tra le quali dividere le spese, sarà sufficiente inserire l'imporo speso da ognuno, recarsi poi nella pagina del conguaglio e riscuotere i propri soldi.

È anche possibile correggere gli importi, specificando quanto deve pagare in più rispetto alle altre ogni persona.


Licenza
----
Questo progetto è rilasciato sotto licenza GPL v3.

Basato su Mobile Angular UI, Copyright (c) 2013 mcasimir (https://github.com/mcasimir).
Ogni componente del suddetto framework è da intendersi sotto la licenza originale.
